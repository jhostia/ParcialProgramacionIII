﻿namespace Presentacion
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            var programa = new PresentacionPrograma();
            programa.Menu();
        }
    }
}